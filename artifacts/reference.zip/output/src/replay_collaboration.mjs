import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const inputRoot = process.cwd();
const outputRoot = path.resolve(inputRoot, '..', 'output');
const reportRoot = path.join(outputRoot, 'reports');
const ownSource = await fs.readFile(fileURLToPath(import.meta.url), 'utf8');
const assert = (value, message) => { if (!value) throw new Error(message); };

function csvCell(value) {
  const text = String(value ?? '');
  return /[",\r\n]/u.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}
function toCsv(headers, rows) { return `${headers.join(',')}\n${rows.map((row) => headers.map((header) => csvCell(row[header])).join(',')).join('\n')}\n`; }

async function main() {
  const sourceText = await fs.readFile(path.join(inputRoot, 'data', 'collaboration_ops.ndjson'), 'utf8');
  const lines = sourceText.split(/\r?\n/u).filter((line) => line.trim());
  const raw = lines.map((line, index) => {
    try { return JSON.parse(line); } catch (error) { throw new Error(`操作流第${index + 1}行不是合法JSON`); }
  });
  const members = JSON.parse(await fs.readFile(path.join(inputRoot, 'data', 'members.json'), 'utf8'));
  const policy = JSON.parse(await fs.readFile(path.join(inputRoot, 'rules', 'causal_policy.json'), 'utf8'));
  assert(Array.isArray(raw) && raw.length > 0, '操作流不能为空');
  assert(Array.isArray(members) && members.length > 0, '成员清单不能为空');
  assert(typeof policy.document_id === 'string' && policy.document_id, '策略缺少document_id');
  assert(policy.canonical_revision?.primary === 'revision_desc' && policy.canonical_revision?.tie_breaker === 'ingest_seq_desc', '修订收敛规则不受支持');
  assert(JSON.stringify(policy.ready_order) === JSON.stringify(['received_at_asc', 'op_id_asc']), '就绪排序规则不受支持');
  assert(new Set(policy.terminal_advances_clock ?? []).size === 2 && policy.terminal_advances_clock.includes('accepted') && policy.terminal_advances_clock.includes('rejected'), '终态时钟规则不完整');

  const memberById = new Map();
  for (const member of members) {
    assert(member && typeof member.actor_id === 'string' && member.actor_id, '成员缺少actor_id');
    assert(!memberById.has(member.actor_id), `成员重复:${member.actor_id}`);
    assert(Array.isArray(policy.permissions?.[member.role]), `角色未配置权限:${member.role}`);
    assert(['active', 'suspended'].includes(member.account_status), `账户状态无效:${member.actor_id}`);
    memberById.set(member.actor_id, member);
  }
  const ingestIds = new Set();
  const kinds = new Set(Object.values(policy.permissions).flat());
  for (const row of raw) {
    assert(Number.isInteger(row.ingest_seq) && row.ingest_seq > 0 && !ingestIds.has(row.ingest_seq), 'ingest_seq必须为不重复正整数');
    ingestIds.add(row.ingest_seq);
    assert(typeof row.op_id === 'string' && row.op_id && Number.isInteger(row.revision) && row.revision > 0, 'op_id或revision无效');
    assert(memberById.has(row.actor_id), `操作引用未知成员:${row.actor_id}`);
    assert(Number.isInteger(row.actor_seq) && row.actor_seq > 0, `actor_seq无效:${row.op_id}`);
    assert(row.dependencies && typeof row.dependencies === 'object' && !Array.isArray(row.dependencies), `dependencies无效:${row.op_id}`);
    assert(Object.entries(row.dependencies).every(([actor, seq]) => memberById.has(actor) && Number.isInteger(seq) && seq >= 0), `dependencies引用无效:${row.op_id}`);
    assert(!Number.isNaN(Date.parse(row.received_at)), `received_at无效:${row.op_id}`);
    assert(kinds.has(row.kind) && typeof row.block_id === 'string' && typeof row.payload === 'string', `操作类型或内容无效:${row.op_id}`);
  }

  const canonical = new Map();
  for (const row of raw) {
    const old = canonical.get(row.op_id);
    if (!old || row.revision > old.revision || (row.revision === old.revision && row.ingest_seq > old.ingest_seq)) canonical.set(row.op_id, row);
  }
  const currentClock = Object.fromEntries(members.map((member) => [member.actor_id, 0]));
  const blocks = new Map();
  const comments = [];
  const terminal = new Map();
  const pending = [...canonical.values()];
  let nextOrdinal = 1;
  let causalRank = 0;

  while (pending.length) {
    const ready = pending.filter((op) => op.actor_seq === currentClock[op.actor_id] + 1 && Object.entries(op.dependencies).every(([actor, seq]) => currentClock[actor] >= seq))
      .sort((left, right) => left.received_at.localeCompare(right.received_at) || left.op_id.localeCompare(right.op_id));
    if (!ready.length) break;
    const op = ready[0];
    pending.splice(pending.indexOf(op), 1);
    causalRank += 1;
    const member = memberById.get(op.actor_id);
    let decision = 'accepted';
    let reason = 'applied';
    let effectApplied = false;
    if (member.account_status !== 'active') { decision = 'rejected'; reason = 'account_suspended'; }
    else if (!policy.permissions[member.role].includes(op.kind)) { decision = 'rejected'; reason = 'role_forbidden'; }
    else if (op.kind === 'insert' && blocks.has(op.block_id)) { decision = 'rejected'; reason = 'block_already_exists'; }
    else if (op.kind !== 'insert' && (!blocks.has(op.block_id) || blocks.get(op.block_id).deleted)) { decision = 'rejected'; reason = 'target_not_active'; }
    if (decision === 'accepted') {
      effectApplied = true;
      if (op.kind === 'insert') blocks.set(op.block_id, { block_id: op.block_id, text: op.payload, ordinal: nextOrdinal++, last_op_id: op.op_id, deleted: false });
      if (op.kind === 'edit') { const block = blocks.get(op.block_id); block.text = op.payload; block.last_op_id = op.op_id; }
      if (op.kind === 'delete') { const block = blocks.get(op.block_id); block.deleted = true; block.last_op_id = op.op_id; }
      if (op.kind === 'comment') comments.push({ comment_id: op.op_id, block_id: op.block_id, actor_id: op.actor_id, text: op.payload });
    }
    currentClock[op.actor_id] = op.actor_seq;
    terminal.set(op.op_id, { decision, reason, causal_rank: causalRank, member_role: member.role, actor_clock_after: currentClock[op.actor_id], effect_applied: effectApplied });
  }

  const decisionRows = [...raw].sort((left, right) => left.ingest_seq - right.ingest_seq).map((row) => {
    const chosen = canonical.get(row.op_id);
    if (chosen.ingest_seq !== row.ingest_seq) return { ...row, dependencies: JSON.stringify(row.dependencies), decision: 'superseded_revision', reason: 'newer_revision_present', causal_rank: '', member_role: memberById.get(row.actor_id).role, actor_clock_after: '' };
    const state = terminal.get(row.op_id);
    return { ...row, dependencies: JSON.stringify(row.dependencies), decision: state?.decision ?? 'unresolved', reason: state?.reason ?? 'causal_dependency_unresolved', causal_rank: state?.causal_rank ?? '', member_role: state?.member_role ?? memberById.get(row.actor_id).role, actor_clock_after: state?.actor_clock_after ?? '' };
  });
  const activeBlocks = [...blocks.values()].filter((block) => !block.deleted).sort((left, right) => left.ordinal - right.ordinal).map(({ deleted, ...block }) => block);
  const deletedBlockIds = [...blocks.values()].filter((block) => block.deleted).map((block) => block.block_id).sort();
  comments.sort((left, right) => left.comment_id.localeCompare(right.comment_id));
  const snapshot = { document_id: policy.document_id, active_blocks: activeBlocks, deleted_block_ids: deletedBlockIds, comments };
  const clockRows = [...members].sort((left, right) => left.actor_id.localeCompare(right.actor_id)).map((member) => ({
    actor_id: member.actor_id,
    role: member.role,
    account_status: member.account_status,
    observed_seq: currentClock[member.actor_id],
    terminal_operation_count: [...terminal.keys()].filter((opId) => canonical.get(opId).actor_id === member.actor_id).length,
  }));
  const measures = {
    raw_operation_rows: raw.length,
    canonical_operation_count: canonical.size,
    superseded_revision_count: decisionRows.filter((row) => row.decision === 'superseded_revision').length,
    accepted_operation_count: decisionRows.filter((row) => row.decision === 'accepted').length,
    rejected_operation_count: decisionRows.filter((row) => row.decision === 'rejected').length,
    unresolved_operation_count: decisionRows.filter((row) => row.decision === 'unresolved').length,
    active_block_count: activeBlocks.length,
    deleted_block_count: deletedBlockIds.length,
    comment_count: comments.length,
    actor_clock_rows: clockRows.length,
    final_causal_rank: causalRank,
  };
  const relationships = {
    decision_rows_cover_raw_input: decisionRows.length === raw.length,
    one_canonical_revision_per_op: canonical.size === new Set(raw.map((row) => row.op_id)).size,
    superseded_revisions_never_applied: decisionRows.filter((row) => row.decision === 'superseded_revision').every((row) => canonical.get(row.op_id).ingest_seq !== row.ingest_seq),
    canonical_operations_all_terminal: pending.length === 0 && terminal.size === canonical.size,
    terminal_counts_reconcile: measures.accepted_operation_count + measures.rejected_operation_count === measures.canonical_operation_count,
    actor_clocks_reach_terminal_sequences: clockRows.every((row) => row.observed_seq === Math.max(0, ...[...canonical.values()].filter((op) => op.actor_id === row.actor_id).map((op) => op.actor_seq))),
    rejected_operations_have_no_effect: [...terminal.values()].filter((state) => state.decision === 'rejected').every((state) => state.effect_applied === false),
    active_block_ids_unique: new Set(activeBlocks.map((block) => block.block_id)).size === activeBlocks.length,
    comments_target_active_blocks: comments.every((comment) => activeBlocks.some((block) => block.block_id === comment.block_id)),
    active_blocks_follow_insert_order: activeBlocks.every((block, index, rows) => index === 0 || rows[index - 1].ordinal < block.ordinal),
    no_unresolved_operations: measures.unresolved_operation_count === 0,
  };
  measures.inconsistency_count = Object.values(relationships).filter((value) => value !== true).length;
  const reconciliation = { result: measures.inconsistency_count === 0 ? 'PASS' : 'FAIL', measures, relationships };
  await fs.rm(reportRoot, { recursive: true, force: true });
  await fs.mkdir(path.join(outputRoot, 'src'), { recursive: true });
  await fs.mkdir(reportRoot, { recursive: true });
  await fs.writeFile(path.join(outputRoot, 'src', 'replay_collaboration.mjs'), ownSource);
  const headers = ['ingest_seq','op_id','revision','actor_id','actor_seq','dependencies','received_at','kind','block_id','payload','decision','reason','causal_rank','member_role','actor_clock_after'];
  await fs.writeFile(path.join(reportRoot, 'operation_decisions.csv'), toCsv(headers, decisionRows));
  await fs.writeFile(path.join(reportRoot, 'document_snapshot.json'), `${JSON.stringify(snapshot, null, 2)}\n`);
  await fs.writeFile(path.join(reportRoot, 'actor_clocks.csv'), toCsv(['actor_id','role','account_status','observed_seq','terminal_operation_count'], clockRows));
  await fs.writeFile(path.join(reportRoot, 'reconciliation_summary.json'), `${JSON.stringify(reconciliation, null, 2)}\n`);
  assert(reconciliation.result === 'PASS', '因果回放对账未闭合');
  console.log(JSON.stringify({ result: 'PASS', raw_rows: raw.length, canonical_ops: canonical.size, causal_rank: causalRank, active_blocks: activeBlocks.length }));
}

try { await main(); }
catch (error) {
  await fs.rm(reportRoot, { recursive: true, force: true });
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
}
