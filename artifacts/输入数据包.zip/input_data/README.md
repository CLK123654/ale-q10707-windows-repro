# 协作文档因果回放

data/collaboration_ops.ndjson是离线操作流，data/members.json是成员状态，rules/causal_policy.json是因果策略。完成starter/replay_collaboration.mjs后，将业务程序放到同级output/src/replay_collaboration.mjs，再在本目录运行npm run process。入口覆盖生成终态快照、成员时钟、操作台账和对账摘要。
