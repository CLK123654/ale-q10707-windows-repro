import fs from 'node:fs/promises';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const inputRoot = process.cwd();
const outputRoot = path.resolve(inputRoot, '..', 'output');
const reportRoot = path.join(outputRoot, 'reports');
const businessProgram = path.join(outputRoot, 'src', 'replay_collaboration.mjs');
const assert = (value, message) => { if (!value) throw new Error(message); };

function executeProgram() {
  const result = spawnSync(process.execPath, [businessProgram], { cwd: inputRoot, encoding: 'utf8', timeout: 60000, windowsHide: true });
  assert(result.status === 0, `业务程序执行失败:${result.stdout}${result.stderr}`);
  return result.stdout.trim();
}

async function cleanReports() { await fs.rm(reportRoot, { recursive: true, force: true }); }

try {
  assert(path.basename(inputRoot) === 'input_data', '请在input_data目录运行npm run process');
  const policy = JSON.parse(await fs.readFile(path.join(inputRoot, 'rules', 'causal_policy.json'), 'utf8'));
  assert(typeof policy.document_id === 'string' && policy.document_id, '策略缺少document_id');
  assert(policy.canonical_revision?.primary === 'revision_desc' && policy.canonical_revision?.tie_breaker === 'ingest_seq_desc', '不支持的修订收敛规则');
  assert(JSON.stringify(policy.ready_order) === JSON.stringify(['received_at_asc', 'op_id_asc']), '不支持的就绪排序规则');
  assert(new Set(policy.terminal_advances_clock ?? []).size === 2 && policy.terminal_advances_clock.includes('accepted') && policy.terminal_advances_clock.includes('rejected'), '终态时钟规则不完整');
  const required = ['output/src/replay_collaboration.mjs','output/reports/operation_decisions.csv','output/reports/document_snapshot.json','output/reports/actor_clocks.csv','output/reports/reconciliation_summary.json'];
  assert(JSON.stringify(policy.required_outputs) === JSON.stringify(required), '策略交付路径不完整或顺序错误');
  const source = await fs.readFile(businessProgram, 'utf8');
  assert(!source.includes('TODO'), '业务程序仍含TODO');
  await cleanReports();
  const log = executeProgram();
  const reconciliation = JSON.parse(await fs.readFile(path.join(reportRoot, 'reconciliation_summary.json'), 'utf8'));
  assert(reconciliation.result === 'PASS' && Object.values(reconciliation.relationships).every(Boolean), '因果回放对账未闭合');
  console.log(JSON.stringify({ result: 'PASS', node: process.version, program: log, reports: 4 }));
} catch (error) {
  await cleanReports();
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
}
